<div style="text-align: center;">
<ul style=" list-style-type: none;margin: 0; padding: 2px;">
    <li style="display: inline;"><a href="index.php" style="display: block;padding: 8px;background-color: #dddddd;"> Add Data</a></li>
        <li style="display: inline;"><a href="display.php" style="display: block;padding: 8px;background-color: #dddddd;">Display Data</a></li>
        <li style="display: inline;"><a href="search.php" style="display: block;padding: 8px;background-color: #dddddd;"> Search</a></li>
    </ul>
</div>