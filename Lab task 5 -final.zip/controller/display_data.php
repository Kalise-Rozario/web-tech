<?php 

require_once ('model/model.php');

function fetchDisplay(){
	return display();

}
