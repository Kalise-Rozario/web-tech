<?php
require_once ('model/model.php');
function fetchedit($id){
	return edit($id);

}